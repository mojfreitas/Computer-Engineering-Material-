Project: 'GR' created on 2024-12-31
Author: John Doe <john.doe@example.com>

No project description was given