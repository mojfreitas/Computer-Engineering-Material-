<?php

namespace App\Http\Controllers;
use App\Models\Pedidos;
use App\Models\PedidoLog;

class PedidosController extends Controller
{
    public function show()
    {
        return view('pedidos', [
            'pedidos'=> Pedidos::orderBy('created','asc')->get()
        ]);
    }

    public function showLog($doc)
    {
        $pedidoLog = PedidoLog::where('doc','=',$doc)->whereNotNull('status')->get();
        if ($pedidoLog->isEmpty()) {
            abort(404);
        }
        else{
            return view('pedidoLog',['pedidoLog'=>$pedidoLog]);
        }
    }
}




   /* public function search(Request $request ){
        $output = "";
        $ped = Pedidos::where('doc','Like','%'.$request->search.'%')->get();

        foreach($ped as $ped)
        {
            $output.= '<tr>
             <td>'.$ped->doc.'</td>
             </tr>';
        }
        return response($output);
    }*/


