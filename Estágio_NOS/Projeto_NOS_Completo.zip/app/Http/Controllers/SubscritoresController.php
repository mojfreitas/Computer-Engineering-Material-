<?php
namespace App\Http\Controllers;

use App\Models\Subscritores;
use App\Models\SubscribersEmails;
use Illuminate\Http\Request;

//  --------------------------------------- *NOTA* -----------------------------------------//
// Ao criar uma entidade, deve introduzir o NIF e o Broker
// É possível adicionar ou alterar o broker na pagina reservada ao NIF escolhido.
// Se houver o email 'x' com primary=1 e mudarmos o email 'y' com primary = 0 para =1, o email 'x' fica automaticamente =0.
//-----------------------------------------------------------------------------------------//
class SubscritoresController extends Controller
{
//----------------------------- Display das Views ----------------------------------//

//----------------------------- View Subscritores -----------------------------------//
    public function subscribers()
    {
        $subscritores = Subscritores::orderBy('id', 'desc')->get();
        return view('subscritores', [
            'subscritores' => $subscritores
        ]);
    }
//---------------------- View Subscritor -----------------------------------//
    public function subscribersEmails($vat)
    {
        $subscriberEmails = SubscribersEmails::where('vat', $vat)->get();
        $broker = Subscritores::where('vat',$vat)->first()->broker;

        return view('subscritor', ['subscriberEmails' => $subscriberEmails,'vat'=>$vat,'broker'=>$broker]);
    }
//-------------------------- View Create ------------------------------------//
    public function create()
    {
        return view('create');
    }
//-------------------------- View Edit ------------------------------------//
    public function edit($id)
    {
        $editar = SubscribersEmails::where('id', $id)->get();
        if ($editar->isEmpty()) {
            abort(404);
        }
            return view('edit', ['editar' => $editar]);
    }

//------------------------------------------------- VALIDAÇÃO ---------------------------------------------------------------------//
//--------------------------------- Parte de Criar e Validar Entidade (Criar Entidade) -------------------------------------------//
    public function request(Request $request)
{
    $rules = [

        'vat' => [
            'required',
            'size:9',
            'unique:subscribers,vat' => function ($key, $value, $fail) {
                if (Subscritores::where($key, $value)->exists()) {

                    $fail('O NIF já está registado.');
                }
            }
        ],
        'broker' => ['required'],
    ];

    $messages = [
        'vat.required' => 'O NIF é obrigatório.',
        'vat.size' => 'O NIF deve ter exatamente 9 caracteres.',
        'broker.required' => 'O campo Broker é obrigatório.'
    ];

    $request->validate($rules, $messages);

    Subscritores::create([
    'vat' => $request->input('vat'),
     'broker' => $request->input('broker')
     ]);
    return redirect('/entidades');
}

//--------------------------------------------- VALIDAÇÃO NOVO EMAIL --------------------------------------------------------------------------//
public function requestLine(Request $request, $vat){
    $rules =[
        'email' => [
            'required',
            'email',
            'unique:subscribers_emails,email'
        ],
        'primary' => [
            'required',
            'boolean'
        ]
];

    $messages = [
        'email.email' => 'O endereço no campo "Email" deve ser válido.',
        'email.unique' => 'Este email já está registado.',

    ];

    $request->validate($rules, $messages);

    if ($request->input('primary') == 1) {
        // Verificar se já existe um registo com primary igual a 1
        $existingPrimary = SubscribersEmails::where('vat',$vat)->where('primary',1)->first();

        if ($existingPrimary) {
            return redirect()->back()->withErrors(['primary' => 'Já existe um email com o campo Primary definido como 1.'])->withInput();
        }
    }

    SubscribersEmails::create([
        'vat' => $vat,
        'email' => $request->input('email'),
        'primary' => $request->input('primary')
    ]);

    return redirect()->back()->with('success', 'Email adicionado com sucesso.');

}

//----------------------------------------- DELETE (Editar) -------------------------------------------------------//

public function delete($id)
{
    $subscriberEmail = SubscribersEmails::where('id', $id)->first();

    if ($subscriberEmail) {
            $subscriberEmail->delete();
            if (SubscribersEmails::where('id', $id)->exists()) {
                return redirect()->back()->with('error', 'Email não apagado.');
            }else{
                return redirect()->back()->with('success', 'Email do subscritor apagado com sucesso.');
            }

    }
}

// ----------------------------------------- Função para dar update (Editar) --------------------------------------//
public function update(Request $request, $id)
{
    $subscriberEmail = SubscribersEmails::where('id', $id)->firstOrFail();

    if (!$subscriberEmail) {
        abort(404);
    }

    Subscritores::where('vat', $subscriberEmail->vat)->firstOrFail();

    $rules = [
        'primary' => ['required', 'boolean'],
        'email' => [
            'required',
            'email',

            function () use ($request, $subscriberEmail) {
                // Verifica se há um email com primary = 1 diferente do atual
                if ($request->input('primary') == 1 ) {
                    $existingPrimaryEmail = SubscribersEmails::where('vat',$subscriberEmail->vat)
                        ->where('primary', 1)
                        ->where('email', '<>', $subscriberEmail->email)
                        ->first();

                    if ($existingPrimaryEmail) {
                        $existingPrimaryEmail->update(['primary' => 0]);
                    }
                }
                // Display de erro ao editar e colocar um email já usado por outro subscritor
                $emailExistsForAnotherVAT = SubscribersEmails::where('email', $request->input('email'))
                ->where('vat', '<>', $subscriberEmail->vat)
                ->exists();

            if ($emailExistsForAnotherVAT) {
                throw \Illuminate\Validation\ValidationException::withMessages([
                    'email' => 'O email já está em uso por outro subscritor.']);
               }
            }
        ],
    ];

    $messages = [
        'email.required' => 'O campo Email é obrigatório.',
        'email.email' => 'O endereço no campo "Email" deve ser válido.',
        'primary.required' => 'O campo Email Principal é obrigatório.',
    ];

    $request->validate($rules, $messages);

    $subscriberEmail->update([
        'email' => $request->input('email'),
        'primary' => $request->input('primary')
    ]);

    return redirect('/entidades/' . $subscriberEmail->vat);

    }
// ---------------------------------------- Função para dar update ao broker -------------------------------------------------//
    public function updateBroker(Request $request, $vat)
    {
        $subscritor = Subscritores::where('vat',  $vat)->firstOrFail();
        try {
        $subscritor->update([
            'broker' => $request->input('broker'),
        ]);
        return redirect()->back();
        } catch (\Throwable $th) {
    return redirect()->back()->with('error','erro');
        }
    }

    // --------------------------------- Função para apagar subscritor (totalmente) -------------------------------------------------//
    public function deleteSubscriber($vat)
    {
        Subscritores::where('vat',$vat)->firstOrFail()->delete();
        return redirect()->back();
    }

}

