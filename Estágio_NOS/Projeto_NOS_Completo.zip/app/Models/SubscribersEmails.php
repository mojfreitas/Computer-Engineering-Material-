<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SubscribersEmails extends Model
{
    use HasFactory;
    public $tables = 'subscribers_emails';
    protected $fillable = ['vat','email','primary'];
    public $timestamps = false;
}
