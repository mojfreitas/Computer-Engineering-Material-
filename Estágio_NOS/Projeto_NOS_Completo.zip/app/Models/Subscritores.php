<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Subscritores extends Model
{
    use HasFactory;
    protected $table = 'subscribers';
    protected $fillable = ['vat','broker'];
    public $timestamps = false;

}
