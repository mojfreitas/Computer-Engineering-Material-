<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PedidosController;
use App\Http\Controllers\SubscritoresController;
use App\Http\Controllers\HomeController;

// Ver Controllers
Route::get('/', [HomeController::class,'home']);

//Retorna a view subscritores
Route::get('/entidades', [SubscritoresController::class,'subscribers']);

//Aplica as validações
Route::post('/entidades', [SubscritoresController::class,'request']);

//Retorna a view subscritores->Create
Route::get('/entidades/create', [SubscritoresController::class,'create']);

//Retorna a view pedidos
Route::get('/pedidos',[PedidosController::class,'show']);

//Retorna a view pedido
Route::get('/pedidos/{doc}',[PedidosController::class, 'showLog']);

//Retorna a view subscritor
Route::get('/entidades/{vat}', [SubscritoresController::class,'subscribersEmails']);

//Retorna a view edit
Route::get('/email/{id}/edit', [SubscritoresController::class,'edit']);

//Delete
Route::delete('/email/{id}/delete', [SubscritoresController::class,'delete']);
Route::delete('/entidades/{vat}',[SubscritoresController::class,'deleteSubscriber']);

//Criar novos Emails
Route::post('/entidades/{vat}', [SubscritoresController::class,'requestLine']);

//Update
Route::patch('/email/{id}/edit', [SubscritoresController::class,'update']);
Route::patch('/entidades/{vat}',[SubscritoresController::class,'updateBroker']);




//Search Bar
//Route::get('/search',[PedidosController::class,'search']);








