<x-layout>
    <x-slot:heading>
        Novos Dados
    </x-slot:heading>

    <form method="POST" action="/entidades">
        @csrf

        <div class="space-y-12">
            <div class="border-b border-gray-900/10 pb-10">
                <div class="grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-6">
                    <div class="sm:col-span-2">
                        <label for="vat" class="block text-sm font-medium leading-6 text-gray-900"><strong>NIF*</strong></label>
                        <div class="mt-2">
                            <input id="vat" name="vat" type="text" maxlength="9" class="block w-full rounded-md border-0 py-1.5 pl-2 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6" required>

                        </div>
                    </div>
                    <div class="sm:col-span-4">
                        <label for="broker" class="block text-sm font-medium leading-6 text-gray-900"><strong>Broker*</strong></label>
                        <div class="mt-2">
                            <select id="broker" name="broker" class="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:max-w-xs sm:text-sm sm:leading-6" >
                                <option value="" disabled selected hidden>Escolha um tipo de broker</option>
                                <option>eSPap</option>
                                <option>iLink</option>
                                <option>Indra-Minsait</option>
                                <option>YET - Your Electronic Transactions, Lda</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="mt-10">
                    @if($errors->any())
                    <ul>
                        @foreach($errors->all() as $error)
                        <li class="text-red-500 italic">{{ $error }}</li>
                        @endforeach
                    </ul>
                    @endif
                </div>
            </div>
        </div>
        <div class="mt-6 flex items-center justify-end gap-x-6">
            <button type="button" class="text-sm font-semibold leading-6 text-gray-900" onclick="window.location='/entidades'">Cancelar</button>
            <button type="submit" class="rounded-md bg-indigo-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">Guardar</button>
        </div>
    </form>
</x-layout>

