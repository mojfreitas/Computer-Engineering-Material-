<x-layout>
    <x-slot:heading>
        Lista de Pedidos
    </x-slot:heading>


   <!-- <head><script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script></head>
    <div class="container">
        <div class="search flex justify-center my-2">
            <input type="search" name="search" id="search" placeholder="Pesquisar..." class="form-control w-1/3 border border-gray-300 rounded-lg px-3 py-2 shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" onfocus="this.value=''">
        </div>
    </div> -->

    <div class="space-y-4">
        @foreach ($pedidos as $pedido)
            <a href="/pedidos/{{ $pedido['doc'] }}" class="block p-1 bg-white rounded-lg shadow-md hover:shadow-lg hover:bg-blue-200 transition-colors duration-400">
                <div class="overflow-x-auto">
                    <table class="min-w-full table-auto text-left">
                        <thead>
                            <tr class="bg-gray-800 text-gray-200 text-xs leading-normal">
                                <th class="py-1 px-4 border-r border-gray-600">Doc</th>
                                <th class="py-1 px-4 border-r border-gray-600">Invoice</th>
                                <th class="py-1 px-4 border-r border-gray-600">Message</th>
                                <th class="py-1 px-4 border-r border-gray-600">Processed</th>
                                <th class="py-1 px-4 border-r border-gray-600">Last Error</th>
                                <th class="py-1 px-4 border-r border-gray-600">Status</th>
                                <th class="py-1 px-4 border-r border-gray-600">Type</th>
                                <th class="py-1 px-4 border-r border-gray-600">Account</th>
                                <th class="py-1 px-4 border-r border-gray-600">Date</th>
                                <th class="py-1 px-4 border-r border-gray-600">Created</th>
                                <th class="py-1 px-4">Updated</th>
                            </tr>
                        </thead>
                        <tbody class="searchtext-gray-700 text-xs">
                            <tr class="border-gray-200 ">
                                <td class="py-2 px-4 border-r border-gray-200">{{ $pedido['doc'] }}</td>
                                <td class="py-2 px-4 border-r border-gray-200">{{ $pedido['invoice'] }}</td>
                                <td class="py-2 px-4 border-r border-gray-200">{{ $pedido['message'] }}</td>
                                <td class="py-2 px-4 border-r border-gray-200">{{ $pedido['processed'] }}</td>
                                <td class="py-2 px-4 border-r border-gray-200">{{ $pedido['last_error'] ?? '(NULL)' }}</td>
                                <td class="py-2 px-4 border-r border-gray-200">{{ $pedido['status'] }}</td>
                                <td class="py-2 px-4 border-r border-gray-200">{{ $pedido['type'] }}</td>
                                <td class="py-2 px-4 border-r border-gray-200">{{ $pedido['acct'] }}</td>
                                <td class="py-2 px-4 border-r border-gray-200">{{ $pedido['date'] }}</td>
                                <td class="py-2 px-4 border-r border-gray-200">{{ $pedido['created'] }}</td>
                                <td class="py-2 px-4">{{ $pedido['updated'] }}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </a>
        @endforeach
    </div>

<!--<script type="text/javascript">
    $('#search').on('keyup',function()
    {
        $value = $(this).val();

        if($value){
            $('.alldata').hide();
            $('.searchdata').show();
        }
        else{
            $('.alldata').show();
            $('.searchdata').hide();
        }
        $.ajax({
            type:'get',
            url:'{{--  {{URL::to('search')}}   --}}',
            data:{'search':$value},
            success:function(data)
            {
                console.log(data);
                $('#Content').html(data);
            }
        });
    })</script> -->
</x-layout>

