<!-- TEM TAILWIND -->
<!DOCTYPE html>
<html lang="en" class="h-full bg-gray-100">
<head>
<meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Faturação Eletrónica</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="h-full">
<div class="min-h-full">
    <nav style="--tw-bg-opacity: 1; background-color:#175a92fb">
      <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div class="flex h-16 items-center justify-between">
          <div class="flex items-center">
            <div class="flex-shrink-0">
              <img class="h-15 w-20" src="https://upload.wikimedia.org/wikipedia/commons/7/77/Log%C3%B3tipo_da_NOS.png" alt="Your Company">
            </div>
            <div class="hidden md:block">
              <div class="ml-10 flex items-baseline space-x-4">
                <x-nav-link href="/" :active="request()->is('/')">Home</x-nav-link>
                <x-nav-link href="/entidades" :active="request()->is('entidades')">Entidades</x-nav-link>
                <x-nav-link href="/pedidos" :active="request()->is('pedidos')">Pedidos</x-nav-link>
              </div>
            </div>
          </div>
          <div class="hidden md:block">
            <div class="ml-4 flex items-center md:ml-6">

              <!-- Profile dropdown -->
              <div class="relative ml-3">
                <div>
                  <button type="button" class="relative flex max-w-xs items-center rounded-full bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-gray-800" id="user-menu-button" aria-expanded="false" aria-haspopup="true">
                    <span class="absolute -inset-1.5"></span>
                    <span class="sr-only"></span>
                    <img class="h-8 w-8 rounded-full" src="https://i.pinimg.com/736x/0d/64/98/0d64989794b1a4c9d89bff571d3d5842.jpg" alt="">
                  </button>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>

      <!-- Mobile menu, show/hide based on menu state. -->
      <div class="md:hidden" id="mobile-menu">
        <div class="space-y-1 px-2 pb-3 pt-2 sm:px-3">
          <!-- Current: "bg-gray-900 text-white", Default: "text-gray-300 hover:bg-gray-700 hover:text-white" -->
          <x-nav-link href="/" :active="request()->is('/')">Home</x-nav-link>
          <x-nav-link href="/entidades" :active="request()->is('entidades')">Entidades</x-nav-link>
          <x-nav-link href="/pedidos" :active="request()->is('pedidos')">Pedidos</x-nav-link>


        </div>
        <div class="border-t border-gray-700 pb-3 pt-4">
          <div class="flex items-center px-5">
            <div class="flex-shrink-0">
              <img class="h-10 w-10 rounded-full" src="https://i.pinimg.com/736x/0d/64/98/0d64989794b1a4c9d89bff571d3d5842.jpg" alt="">
            </div>
            <div class="ml-3">
              <div class="text-base font-medium leading-relaxed:0.1 text-white ">Martim Freitas</div>
              <div class="text-sm font-medium leading-relaxed:0.1 text-gray-400">martim.freitas@parceiros.nosmadeira.pt</div>
            </div>
          </div>
        </div>
      </div>
    </nav>

    <header class="bg-white shadow">
        <div class="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8 flex justify-between items-center">
          <h1 class="text-3xl font-bold tracking-tight text-gray-900">{{ $heading }}</h1>
          <div class="flex-shrink-0">
            @if(Request::is('entidades') || Request::is('entidades/*'))
                <x-button href="/entidades/create">Criar Entidade</x-button>
            @endif
          </div>
        </div>
      </header>

      <main>
        <div class="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
          {{ $slot }}
        </div>
      </main>
  </div>

</body>
</html>
