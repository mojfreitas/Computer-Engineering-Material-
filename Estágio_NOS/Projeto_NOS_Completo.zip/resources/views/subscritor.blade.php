<x-layout>
    @if (session('error'))
        <div class="bg-red-500 text-white p-2 rounded mb-4">
            {{ session('error') }}
        </div>
    @endif

    @if (session('success'))
        <div class="bg-green-500 text-white p-2 rounded mb-4">
            {{ session('success') }}
        </div>
    @endif

    <!-- ---------------------------------------------- Display:Broker Edition ------------------------------------------------->
    <form method="POST" action="/entidades/{{ $vat }}" class="flex justify-center bg-gray-100 py-2">
        @csrf
        @method('PATCH')
        <div class="bg-white p-2 rounded-md shadow-md w-full max-w-xs">
            <div class="mb-2">
                <label for="broker" class="block text-sm font-medium leading-6 text-gray-900 text-center">
                    <strong>Broker</strong>
                </label>
                <div class="mt-1">
                    <select id="broker" name="broker" class="block w-full rounded-md border-0 py-1 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6">
                        <option value="" disabled hidden>Escolha um tipo de broker</option>
                        <option value="eSPap" {{ $broker == 'eSPap' ? 'selected' : '' }}>eSPap</option>
                        <option value="iLink" {{ $broker == 'iLink' ? 'selected' : '' }}>iLink</option>
                        <option value="Indra-Minsait" {{ $broker == 'Indra-Minsait' ? 'selected' : '' }}>Indra-Minsait</option>
                        <option value="YET - Your Electronic Transactions, Lda" {{ $broker == 'YET - Your Electronic Transactions, Lda' ? 'selected' : '' }}>YET - Your Electronic Transactions, Lda</option>
                    </select>
                </div>
            </div>
            <div class="flex justify-center">
                <button type="submit" class="bg-blue-500 text-white text-xs py-1 px-3 rounded hover:bg-blue-700 transition-colors duration-300">
                    Atualizar Broker
                </button>
            </div>
        </div>
    </form>


    <!-- ---------------------------------------------- Display: Tabela ------------------------------------------------->
    <div class="space-y-2">
            <table class="border-collapse table-auto w-full whitespace-no-wrap bg-white table-striped relative">
                <thead>
                    <tr class="bg-gray-300 sticky top-0 border-b border-gray-200 text-gray-600 font-bold tracking-wider uppercase text-xs text-center">
                        <!-- Opcional -->
                        <!-- <td class="border-r border-gray-300"><strong>id</strong></td> -->
                        <!-- <td class="border-r border-gray-300"><strong>vat</strong></td> -->
                        <td class="border-r border-gray-300"><strong>email</strong></td>
                        <td><strong>primary</strong></td>
                        <td class="" style="width: 200px;"></td>
                    </tr>
                </thead>
                <tbody>
    @if($subscriberEmails)
    @foreach($subscriberEmails as $Email)
                    <tr class="border-dashed border-t border-gray-200 text-sm text-center">
                        <!-- Optional Columns -->
                        <!-- <td class="border-r border-gray-300">{{ $Email->id }}</td> -->
                        <!-- <td class="border-r border-gray-300">{{ $Email->vat }}</td> -->
                        <td class="border-r border-gray-300">{{ $Email->email }}</td>
                        <td>{{ $Email->primary }}</td>
                        <td class="flex justify-center items-center space-x-1">
                            <x-button href="/email/{{ $Email->id }}/edit" class="text-black rounded hover:bg-blue-500 transition-colors duration-300" style="padding: 5px 10px;font-size: 12px;width: auto;height: auto;border: 1px solid #000;border-radius: 3px;">
                                Editar
                            </x-button>
                            <form method="POST" action="/email/{{ $Email->id }}/delete" onsubmit="return confirm('Deseja apagar este email associado ao subscritor: {{ $Email->vat }}?');">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="text-black rounded hover:bg-red-500 transition-colors duration-300" style="padding: 5px 10px;font-size: 12px;width: auto;height: auto;border: 1px solid #000;border-radius: 3px;">
                                    Apagar
                                </button>
                            </form>
                        </td>
                    </tr>
     @endforeach
@endif
                </tbody>
            </table>
        </div>

    <!--------------------------------------------------------------------------------- NOVO EMAIL----------------------------------------------------------------------------------->

    <div class="mb-4 p-3 border border-gray-300 rounded-md bg-gray-100 max-w-md mx-auto mt-2">
        <h2 class="text-sm font-semibold mb-4 text-center"><strong>Adicionar Novo Email</strong></h2>
        <form method="POST" action="/entidades/{{$vat}}">
            @csrf

            <div class="flex items-center space-x-4 mb-4">
                <div class="flex-1">
                    <label for="email" class="block text-s font-medium text-gray-700">Email</label>
                    <input type="email" id="email" name="email" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm text-s px-1" required>
                </div>

                <div class="flex-1">
                    <label for="primary" class="block text-s font-medium text-gray-700">Email Primário?</label>
                    <select id="primary" name="primary" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm text-s" required>
                        <option value="" disabled selected hidden> Escolha uma opção</option>
                        <option value="0">Não</option>
                        <option value="1">Sim</option>
                    </select>
                </div>
            </div>

            <div class="flex justify-center">
                <button type="submit" class="bg-blue-500 text-white text-xs py-1 px-3 rounded hover:bg-blue-700 transition-colors duration-300">
                    Adicionar
                </button>
            </div>
        </form>
    </div>

    @if($errors->any())
    <ul>
        @foreach($errors->all() as $error)
        <li class="text-red-500 italic">{{ $error }}</li>
        @endforeach
    </ul>
    @endif

    <x-slot:heading>
        @if(isset($Email))
        NIF: {{ $Email->vat }}
        @endif
    </x-slot:heading>

</x-layout>


