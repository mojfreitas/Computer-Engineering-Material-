<x-layout>
    <div class="space-y-2">
        <table class="border-collapse table-auto w-full whitespace-no-wrap bg-white table-striped relative">
            <thead class="">
                <tr class="bg-gray-300 sticky top-0 border-b border-gray-200 text-gray-600 font-bold tracking-wider uppercase text-xs text-center">
                    <td class="border-r border-gray-400"><strong>doc</strong></td>
                    <td class="border-r border-gray-400"><strong>message</strong></td>
                    <td class="border-r border-gray-400"><strong>processed</strong></td>
                    <td class="border-r border-gray-400"><strong>error</strong></td>
                    <td class="border-r border-gray-400"><strong>status</strong></td>
                    <td><strong>created</strong></td>
                </tr>
            </thead>
            <tbody>
                @if($pedidoLog)
                    @foreach($pedidoLog as $Log)
                        <tr class="border-dashed border-t border-gray-200 text-sm text-center">
                            <td class="border-r border-gray-400">{{ $Log->doc }}</td>
                            <td class="border-r border-gray-400">{{ $Log->message ??'(NULL)' }}</td>
                            <td class="border-r border-gray-400">{{ $Log->processed }}</td>
                            <td class="border-r border-gray-400">{{ $Log->error ??'(NULL)' }}</td>
                            <td class="border-r border-gray-400">{{ $Log->status ??'(NULL)' }}</td>
                            <td>{{ $Log->created }}</td>
                        </tr>
                    @endforeach
                @endif
            </tbody>
        </table>
    </div>
    <x-slot:heading>
        Pedido -> {{ $Log['doc']}}
    </x-slot:heading>
</x-layout>

