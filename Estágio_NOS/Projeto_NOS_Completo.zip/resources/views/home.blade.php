<x-layout>
    <x-slot:heading>
        Página Inicial
    </x-slot:heading>

    <div class="max-w-3xl mx-auto mt-8 p-6 bg-white rounded-lg shadow-md border border-gray-200">
        <h1 class="text-center text-3xl font-bold text-gray-800 mb-6">
            Bem-Vindo à página inicial! Para prosseguir, escolha uma das opções abaixo:
        </h1>

        <div class="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-4">
            <a href="/entidades" class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-4 px-8 rounded-lg shadow-lg transition-all duration-300 transform hover:scale-105">
                Ir para Entidades
            </a>
            <a href="/pedidos" class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-4 px-8 rounded-lg shadow-lg transition-all duration-300 transform hover:scale-105">
                Ir para Pedidos
            </a>
        </div>
    </div>
</x-layout>



