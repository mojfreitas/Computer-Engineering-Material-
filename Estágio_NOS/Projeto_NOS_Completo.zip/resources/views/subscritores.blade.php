<x-layout>
    <x-slot:heading>
        Lista de Entidades
    </x-slot:heading>

    @if (session('success'))
    <div class="bg-green-500 text-white p-2 rounded mb-4">
        {{ session('success') }}
    </div>
    @endif

    <style>
        .subscriber-box {
            background-color: rgba(9, 185, 255, 0);
            transition: background-color 0.3s ease;
        }

        .subscriber-box:hover {
            background-color: #6b9cc4fb;
        }
    </style>

<div class="space-y-3">
    @if($subscritores)
    @foreach ($subscritores as $subscritor)
        <a href="/entidades/{{ $subscritor['vat'] }}" class="block px-3 py-2 border border-gray-300 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 subscriber-box">
            <div class="flex justify-between h-full items-start">
                <div class="text-large font-semibold">
                    <p class="text-gray-500"><i class="fas fa-id-card"></i> <strong class="text-black">NIF:</strong> {{ $subscritor['vat'] }}</p>
                    <p class=" text-gray-500"><i class="fas fa-briefcase"></i> <strong class="text-black">Broker:</strong> {{ $subscritor['broker'] }}</p>
                </div>
                <div class="flex justify-end items-end">
                    <form method="POST" action="/entidades/{{ $subscritor->vat }}" onsubmit="return confirm('Deseja apagar esta entidade?');">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="text-black rounded hover:bg-red-500 transition-colors duration-300 mt-2" style="padding: 5px 10px;font-size: 12px;width: auto;height: auto;border: 1px solid #000;border-radius: 3px;">
                            Apagar
                        </button>
                    </form>
                </div>
            </div>
        </a>
    @endforeach
    @endif
</div>

</x-layout>
