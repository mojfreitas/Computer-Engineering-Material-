<x-layout>
    @foreach($editar as $edita)
    <x-slot:heading>
        Editar NIF: {{ $edita->vat }}
    </x-slot:heading>
    @endforeach
    <form method="POST" action="/email/{{ $edita->id }}/edit">
        @csrf
        @method('PATCH')
        <div class="space-y-12">
            <div class="border-b border-gray-900/10 pb-10">
                <div class="mt-10 grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-6">
                    <div class="sm:col-span-3">
                        <label for="email" class="block text-sm font-medium leading-6 text-gray-900"><strong>Email</strong></label>
                        <div class="mt-2">
                            <input type="text" name="email" id="email" autocomplete="email" class="block w-full rounded-md border-0 py-1.5 pl-2 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6" placeholder="Introduza um endereço de email"
                            value="{{ $edita->email}}">
                        </div>
                    </div>
                    <div class="sm:col-span-3">
                        <label for="primary" class="block text-sm font-medium leading-6 text-gray-900"><strong>Email Principal?</strong></label>
                        <div class="mt-2">
                            <select id="primary" name="primary" class="block w-1/4 rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:max-w-xs sm:text-sm sm:leading-6">

                                <option value="1" {{ $edita->primary == '1' ? 'selected' : '' }}>Sim</option>
                                <option value="0" {{ $edita->primary == '0' ? 'selected' : '' }}>Não</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="mt-10">
                    @if($errors->any())
                    <ul>
                        @foreach($errors->all() as $error)
                        <li class="text-red-500 italic">{{ $error }}</li>
                        @endforeach
                    </ul>
                    @endif
                </div>
            </div>
        </div>
        <div class="mt-6 flex items-center justify-end gap-x-6">
            <button type="button" class="px-1 text-sm font-semibold leading-6 text-gray-900 hover:text-red-500 transition-colors duration-200" onclick="window.location='/subscritores/{{ $edita->vat }}'">Cancelar</button>
            <button type="submit" class="rounded-md bg-indigo-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">Guardar Alterações</button>
        </div>
    </form>
</x-layout>
