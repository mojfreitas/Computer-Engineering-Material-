/*==============================================================*/
/* DBMS name:      ORACLE Version 11g                           */
/* Created on:     09/12/2023 18:29:34                          */
/*==============================================================*/


alter table CONSULTA
   drop constraint FK_CONSULTA_AGENDA_RECECION;

alter table CONSULTA
   drop constraint FK_CONSULTA_MEDICO_CO_MEDICO;

alter table CONSULTA
   drop constraint FK_CONSULTA_UTENTE_CO_UTENTE;

alter table EXAME
   drop constraint FK_EXAME_CONTEM_REGISTO_;

alter table EXAME
   drop constraint FK_EXAME_EXAME_CON_CONSULTA;

alter table EXAME
   drop constraint FK_EXAME_EXIGE_TIPO_EXA;

alter table EXAME
   drop constraint FK_EXAME_PEDE_MEDICO;

alter table EXAME
   drop constraint FK_EXAME_REALIZA_UTENTE;

alter table MARCACAO
   drop constraint FK_MARCACAO_FAZ_RECECION;

alter table MARCACAO
   drop constraint FK_MARCACAO_MARCACAO__CONSULTA;

alter table MARCACAO
   drop constraint FK_MARCACAO_MEDICO_MA_MEDICO;

alter table MARCACAO
   drop constraint FK_MARCACAO_UTENTE_MA_UTENTE;

alter table MEDICO
   drop constraint FK_MEDICO_TEM_ESPECIAL;

alter table REGISTO_CLINICO
   drop constraint FK_REGISTO__ASSOCIADO_UTENTE;

alter table REGISTO_CLINICO
   drop constraint FK_REGISTO__PREENCHE_MEDICO;

alter table UTENTE_DOENCA
   drop constraint FK_UTENTE_D_UTENTE_DO_DOENCAS;

alter table UTENTE_DOENCA
   drop constraint FK_UTENTE_D_UTENTE_DO_UTENTE;

drop index AGENDA_FK;

drop index MEDICO_CONSULTA_FK;

drop index UTENTE_CONSULTA_FK;

drop table CONSULTA cascade constraints;

drop table DOENCAS cascade constraints;

drop table ESPECIALIDADE cascade constraints;

drop index EXAME_CONSULTA_FK;

drop index EXIGE_FK;

drop index PEDE_FK;

drop index REALIZA_FK;

drop index CONTEM_FK;

drop table EXAME cascade constraints;

drop index MARCACAO_CONSULTA_FK;

drop index FAZ_FK;

drop index MEDICO_MARCACAO_FK;

drop index UTENTE_MARCACAO_FK;

drop table MARCACAO cascade constraints;

drop index TEM_FK;

drop table MEDICO cascade constraints;

drop table RECECIONISTA cascade constraints;

drop index PREENCHE_FK;

drop index ASSOCIADO_FK;

drop table REGISTO_CLINICO cascade constraints;

drop table TIPO_EXAME cascade constraints;

drop table UTENTE cascade constraints;

drop index UTENTE_DOENCA2_FK;

drop index UTENTE_DOENCA_FK;

drop table UTENTE_DOENCA cascade constraints;

/*==============================================================*/
/* Table: CONSULTA                                              */
/*==============================================================*/
create table CONSULTA 
(
   ID_CONSULTA          NUMBER(9)            not null,
   N__ORDEM             NUMBER(6),
   N__ID_REC            NUMBER(6),
   N___DE_UTENTE        NUMBER(9),
   DATA_CONS            DATE                 not null,
   constraint PK_CONSULTA primary key (ID_CONSULTA)
);

/*==============================================================*/
/* Index: UTENTE_CONSULTA_FK                                    */
/*==============================================================*/
create index UTENTE_CONSULTA_FK on CONSULTA (
   N___DE_UTENTE ASC
);

/*==============================================================*/
/* Index: MEDICO_CONSULTA_FK                                    */
/*==============================================================*/
create index MEDICO_CONSULTA_FK on CONSULTA (
   N__ORDEM ASC
);

/*==============================================================*/
/* Index: AGENDA_FK                                             */
/*==============================================================*/
create index AGENDA_FK on CONSULTA (
   N__ID_REC ASC
);

/*==============================================================*/
/* Table: DOENCAS                                               */
/*==============================================================*/
create table DOENCAS 
(
   COD_DOENCA           NUMBER(9)            not null,
   NOME_DOENCA          VARCHAR2(20)         not null,
   SINTOMAS_DOENCA      VARCHAR2(100),
   constraint PK_DOENCAS primary key (COD_DOENCA)
);

/*==============================================================*/
/* Table: ESPECIALIDADE                                         */
/*==============================================================*/
create table ESPECIALIDADE 
(
   COD_ESP              NUMBER(3)            not null,
   NOME_ESP             VARCHAR2(20)         not null,
   constraint PK_ESPECIALIDADE primary key (COD_ESP)
);

/*==============================================================*/
/* Table: EXAME                                                 */
/*==============================================================*/
create table EXAME 
(
   N__EXAME             NUMBER(9)            not null,
   N___DE_UTENTE        NUMBER(9),
   ID_REGISTO           NUMBER(9),
   N__ORDEM             NUMBER(6),
   ID_CONSULTA          NUMBER(9),
   COD_EXAME            NUMBER(9),
   RESULTADO            VARCHAR2(50)         not null,
   DATA_EX              DATE                 not null,
   constraint PK_EXAME primary key (N__EXAME)
);

/*==============================================================*/
/* Index: CONTEM_FK                                             */
/*==============================================================*/
create index CONTEM_FK on EXAME (
   ID_REGISTO ASC
);

/*==============================================================*/
/* Index: REALIZA_FK                                            */
/*==============================================================*/
create index REALIZA_FK on EXAME (
   N___DE_UTENTE ASC
);

/*==============================================================*/
/* Index: PEDE_FK                                               */
/*==============================================================*/
create index PEDE_FK on EXAME (
   N__ORDEM ASC
);

/*==============================================================*/
/* Index: EXIGE_FK                                              */
/*==============================================================*/
create index EXIGE_FK on EXAME (
   COD_EXAME ASC
);

/*==============================================================*/
/* Index: EXAME_CONSULTA_FK                                     */
/*==============================================================*/
create index EXAME_CONSULTA_FK on EXAME (
   ID_CONSULTA ASC
);

/*==============================================================*/
/* Table: MARCACAO                                              */
/*==============================================================*/
create table MARCACAO 
(
   ID_MARCACAO          NUMBER(9)            not null,
   ID_CONSULTA          NUMBER(9),
   N__ORDEM             NUMBER(6),
   N___DE_UTENTE        NUMBER(9),
   N__ID_REC            NUMBER(6),
   NOME_MARCACAO        VARCHAR2(50)         not null,
   COMPARENCIA          SMALLINT,
   constraint PK_MARCACAO primary key (ID_MARCACAO)
);

/*==============================================================*/
/* Index: UTENTE_MARCACAO_FK                                    */
/*==============================================================*/
create index UTENTE_MARCACAO_FK on MARCACAO (
   N___DE_UTENTE ASC
);

/*==============================================================*/
/* Index: MEDICO_MARCACAO_FK                                    */
/*==============================================================*/
create index MEDICO_MARCACAO_FK on MARCACAO (
   N__ORDEM ASC
);

/*==============================================================*/
/* Index: FAZ_FK                                                */
/*==============================================================*/
create index FAZ_FK on MARCACAO (
   N__ID_REC ASC
);

/*==============================================================*/
/* Index: MARCACAO_CONSULTA_FK                                  */
/*==============================================================*/
create index MARCACAO_CONSULTA_FK on MARCACAO (
   ID_CONSULTA ASC
);

/*==============================================================*/
/* Table: MEDICO                                                */
/*==============================================================*/
create table MEDICO 
(
   N__ORDEM             NUMBER(6)            not null,
   COD_ESP              NUMBER(3),
   E_MAIL_MED           VARCHAR2(30)         not null,
   N_TELEMOVEL_MED      NUMBER(9)            not null,
   NOME_MED             VARCHAR2(50)         not null,
   constraint PK_MEDICO primary key (N__ORDEM)
);

/*==============================================================*/
/* Index: TEM_FK                                                */
/*==============================================================*/
create index TEM_FK on MEDICO (
   COD_ESP ASC
);

/*==============================================================*/
/* Table: RECECIONISTA                                          */
/*==============================================================*/
create table RECECIONISTA 
(
   N__ID_REC            NUMBER(6)            not null,
   NOME_REC             VARCHAR2(50)         not null,
   E_MAIL_REC           VARCHAR2(30)         not null,
   N__TELEMOVEL_REC     NUMBER(9)            not null,
   constraint PK_RECECIONISTA primary key (N__ID_REC)
);

/*==============================================================*/
/* Table: REGISTO_CLINICO                                       */
/*==============================================================*/
create table REGISTO_CLINICO 
(
   ID_REGISTO           NUMBER(9)            not null,
   N__ORDEM             NUMBER(6),
   N___DE_UTENTE        NUMBER(9),
   EXAME_PEDIDO         VARCHAR2(30),
   DATA_REG             DATE                 not null,
   DIAGNOSTICO          VARCHAR2(100)        not null,
   SINTOMAS_REG         VARCHAR2(100),
   constraint PK_REGISTO_CLINICO primary key (ID_REGISTO)
);

/*==============================================================*/
/* Index: ASSOCIADO_FK                                          */
/*==============================================================*/
create index ASSOCIADO_FK on REGISTO_CLINICO (
   N___DE_UTENTE ASC
);

/*==============================================================*/
/* Index: PREENCHE_FK                                           */
/*==============================================================*/
create index PREENCHE_FK on REGISTO_CLINICO (
   N__ORDEM ASC
);

/*==============================================================*/
/* Table: TIPO_EXAME                                            */
/*==============================================================*/
create table TIPO_EXAME 
(
   COD_EXAME            NUMBER(9)            not null,
   NOME_EXAME           VARCHAR2(20)         not null,
   constraint PK_TIPO_EXAME primary key (COD_EXAME)
);

/*==============================================================*/
/* Table: UTENTE                                                */
/*==============================================================*/
create table UTENTE 
(
   N___DE_UTENTE        NUMBER(9)            not null,
   N_DE_TELEMOVEL_UT    NUMBER(9)            not null,
   NOME_UT              VARCHAR2(50)         not null,
   MORADA               VARCHAR2(50)         not null,
   DATA_NASC            DATE                 not null,
   E_MAIL_UT            VARCHAR2(30),
   TIPO_SANGUINEO       VARCHAR2(3)          not null,
   NUM_PROCESSO         NUMBER(8)            not null,
   constraint PK_UTENTE primary key (N___DE_UTENTE)
);

/*==============================================================*/
/* Table: UTENTE_DOENCA                                         */
/*==============================================================*/
create table UTENTE_DOENCA 
(
   COD_DOENCA           NUMBER(9)            not null,
   N___DE_UTENTE        NUMBER(9)            not null,
   constraint PK_UTENTE_DOENCA primary key (COD_DOENCA, N___DE_UTENTE)
);

/*==============================================================*/
/* Index: UTENTE_DOENCA_FK                                      */
/*==============================================================*/
create index UTENTE_DOENCA_FK on UTENTE_DOENCA (
   COD_DOENCA ASC
);

/*==============================================================*/
/* Index: UTENTE_DOENCA2_FK                                     */
/*==============================================================*/
create index UTENTE_DOENCA2_FK on UTENTE_DOENCA (
   N___DE_UTENTE ASC
);

alter table CONSULTA
   add constraint FK_CONSULTA_AGENDA_RECECION foreign key (N__ID_REC)
      references RECECIONISTA (N__ID_REC);

alter table CONSULTA
   add constraint FK_CONSULTA_MEDICO_CO_MEDICO foreign key (N__ORDEM)
      references MEDICO (N__ORDEM);

alter table CONSULTA
   add constraint FK_CONSULTA_UTENTE_CO_UTENTE foreign key (N___DE_UTENTE)
      references UTENTE (N___DE_UTENTE);

alter table EXAME
   add constraint FK_EXAME_CONTEM_REGISTO_ foreign key (ID_REGISTO)
      references REGISTO_CLINICO (ID_REGISTO);

alter table EXAME
   add constraint FK_EXAME_EXAME_CON_CONSULTA foreign key (ID_CONSULTA)
      references CONSULTA (ID_CONSULTA);

alter table EXAME
   add constraint FK_EXAME_EXIGE_TIPO_EXA foreign key (COD_EXAME)
      references TIPO_EXAME (COD_EXAME);

alter table EXAME
   add constraint FK_EXAME_PEDE_MEDICO foreign key (N__ORDEM)
      references MEDICO (N__ORDEM);

alter table EXAME
   add constraint FK_EXAME_REALIZA_UTENTE foreign key (N___DE_UTENTE)
      references UTENTE (N___DE_UTENTE);

alter table MARCACAO
   add constraint FK_MARCACAO_FAZ_RECECION foreign key (N__ID_REC)
      references RECECIONISTA (N__ID_REC);

alter table MARCACAO
   add constraint FK_MARCACAO_MARCACAO__CONSULTA foreign key (ID_CONSULTA)
      references CONSULTA (ID_CONSULTA);

alter table MARCACAO
   add constraint FK_MARCACAO_MEDICO_MA_MEDICO foreign key (N__ORDEM)
      references MEDICO (N__ORDEM);

alter table MARCACAO
   add constraint FK_MARCACAO_UTENTE_MA_UTENTE foreign key (N___DE_UTENTE)
      references UTENTE (N___DE_UTENTE);

alter table MEDICO
   add constraint FK_MEDICO_TEM_ESPECIAL foreign key (COD_ESP)
      references ESPECIALIDADE (COD_ESP);

alter table REGISTO_CLINICO
   add constraint FK_REGISTO__ASSOCIADO_UTENTE foreign key (N___DE_UTENTE)
      references UTENTE (N___DE_UTENTE);

alter table REGISTO_CLINICO
   add constraint FK_REGISTO__PREENCHE_MEDICO foreign key (N__ORDEM)
      references MEDICO (N__ORDEM);

alter table UTENTE_DOENCA
   add constraint FK_UTENTE_D_UTENTE_DO_DOENCAS foreign key (COD_DOENCA)
      references DOENCAS (COD_DOENCA);

alter table UTENTE_DOENCA
   add constraint FK_UTENTE_D_UTENTE_DO_UTENTE foreign key (N___DE_UTENTE)
      references UTENTE (N___DE_UTENTE);

