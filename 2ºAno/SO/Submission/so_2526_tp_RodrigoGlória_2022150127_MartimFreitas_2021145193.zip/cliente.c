#include "comum.h"
#include <sys/select.h> 

char pipe_cliente[100];
int fd_controlador;

// ============================================================================
// FUNÇÕES AUXILIARES
// ============================================================================

void sair() {
    printf("\n[CLIENTE] A desligar...\n");
    if (fd_controlador != -1) close(fd_controlador);
    unlink(pipe_cliente);
}

// Trata Sinais
void trataSinais(int s) {
    if (s == SIGUSR1) {
        printf("\n[AVISO] O Controlador encerrou o sistema. A sair...\n");
    }
    // O fecho do processo pai aciona o término do filho via pipe de monitorização
    exit(0); 
}

// ============================================================================
// RECEÇÃO (FILHO)
// ============================================================================

void receberMensagens(int fd_monitor_pai) {
    // Monitorização simultânea do pipe do servidor e do estado do processo pai.
    int fd_recebe = open(pipe_cliente, O_RDWR); 
    if(fd_recebe == -1) {
        perror("[ERRO] Falha ao abrir pipe de leitura");
        exit(1);
    }

    Mensagem resp;
    fd_set read_fds;
    // O número máximo do descritor para o select (+1)
    int max_fd = (fd_recebe > fd_monitor_pai) ? fd_recebe : fd_monitor_pai;

    while (1) {
        // I/O Multiplexing: Aguarda dados do controlador ou sinal de término do processo pai
        FD_ZERO(&read_fds);
        FD_SET(fd_recebe, &read_fds);       // Vigiar mensagens do Controlador
        FD_SET(fd_monitor_pai, &read_fds);  // Vigiar se o Pai morreu

        // Bloquear aqui à espera de qualquer coisa 
        if (select(max_fd + 1, &read_fds, NULL, NULL, NULL) == -1) {
            if (errno == EINTR) continue; // Se foi um sinal, volta a tentar
            break;
        }

        // Se o descritor do pipe de monitorização estiver pronto para leitura (EOF),
        // significa que o processo pai terminou inesperadamente.
        if (FD_ISSET(fd_monitor_pai, &read_fds)) {
            break; 
        }

        //Se o pai está vivo, faz processamento normal de mensagens do servidor)
        if (FD_ISSET(fd_recebe, &read_fds)) {
            int n = read(fd_recebe, &resp, sizeof(resp));
            if (n > 0) {
                if(strcmp(resp.comando, "status") == 0) {
                    printf("[VEÍCULO] %s\n", resp.mensagem);
                } 
                else if(strstr(resp.mensagem, "concluída") != NULL || strcmp(resp.comando, "fim") == 0){
                    printf("[VEÍCULO] Viagem terminada. (Podes agendar nova viagem)\n");
                }
                else if(strcmp(resp.comando, "exit_ok") == 0) {
                    printf("[SISTEMA] Saída autorizada. Até à próxima!\n");
                    kill(getppid(), SIGINT); // Avisa o pai para sair
                    exit(0);
                }
                else if(strcmp(resp.comando, "erro") == 0) {
                    printf("[ERRO] %s\n", resp.mensagem);
                }
                else {
                    printf("[CONTROLADOR] %s\n", resp.mensagem);
                }
                printf("> "); 
                fflush(stdout);
            }
        }
    }
    close(fd_recebe);
    close(fd_monitor_pai);
    exit(0);
}

// ============================================================================
// ENVIO (PAI)
// ============================================================================

void enviarComandos(const char *username) {
    char input[100];
    Mensagem msg;
    
    msg.pid = getpid();
    strcpy(msg.username, username);

    printf("\n--- Comandos Disponíveis ---\n");
    printf(" agendar <hora> <local> <km>\n");
    printf(" cancelar <ID>\n");
    printf(" consultar\n");
    printf(" decisao <ID> <s/n>\n");
    printf(" terminar\n");
    printf("----------------------------\n");

    while (1) {   
        printf("> ");
        if (fgets(input, sizeof(input), stdin) == NULL) break;
        
        size_t len = strlen(input);
        if (len > 0 && input[len-1] == '\n') input[len-1] = '\0';
        if (strlen(input) == 0) continue;

        char *cmd = strtok(input, " ");
        char *args = strtok(NULL, ""); 
        
        if (args == NULL && len > strlen(cmd)) {
             args = input + strlen(cmd) + 1;
             if (*args == '\0') args = NULL;
        }
        if (cmd == NULL) continue;

        strcpy(msg.comando, cmd);
        if (args != NULL) strcpy(msg.mensagem, args);
        else msg.mensagem[0] = '\0';

        if(strcmp(cmd, "agendar") == 0 || strcmp(cmd, "consultar") == 0 || 
           strcmp(cmd, "cancelar") == 0 || strcmp(cmd,"decisao") == 0 || 
           strcmp(cmd, "terminar") == 0) {
            write(fd_controlador, &msg, sizeof(Mensagem));
        } else {
            printf("Comando desconhecido ou inválido.\n");
        }
    } 
}

int main(int argc, char *argv[]) {
    setbuf(stdout, NULL); 
    
    if (argc != 2) {
        printf("Uso: ./cliente <username>\n");
        return 1;
    }

    Mensagem aux; 
    if (strlen(argv[1]) > sizeof(aux.username) - 1) {
        printf("[ERRO] O nome é demasiado longo!\n");
        return 1;
    }

    if (access(PIPE_CONTROLADOR, F_OK) == -1) {
        printf("[ERRO] Controlador inativo.\n");
        return 1;
    }

    fd_controlador = open(PIPE_CONTROLADOR, O_WRONLY);
    if (fd_controlador == -1) return 1;

    sprintf(pipe_cliente, PIPE_CLIENTE, getpid());
    if (mkfifo(pipe_cliente, 0666) == -1 && errno != EEXIST) return 1;

    int fd_resposta = open(pipe_cliente, O_RDWR);
    if (fd_resposta == -1) {
        perror("[ERRO] Pipe resposta falhou");
        return 1;
    }

    // Configura SINAIS
    signal(SIGINT, trataSinais);
    signal(SIGUSR1, trataSinais); 
    signal(SIGTERM, trataSinais); // Captura o kill normal
    atexit(sair);

    printf("[CLIENTE %s] PID %d\n", argv[1], getpid());

    // LOGIN
    Mensagem login;
    login.pid = getpid();
    strcpy(login.username, argv[1]);
    strcpy(login.comando, "login");
    strcpy(login.mensagem, "Entrei"); 
    
    write(fd_controlador, &login, sizeof(Mensagem));

    Mensagem resposta;
    if(read(fd_resposta, &resposta, sizeof(Mensagem))<=0){
        printf("[ERRO] Falha ao ler resposta.\n");
        close(fd_resposta);
        return 1;
    }
    close(fd_resposta);

    if (strcmp(resposta.comando, "erro") == 0) {
        printf("[ERRO] %s\n", resposta.mensagem);
        unlink(pipe_cliente); 
        return 1; 
    }

    printf("[SUCESSO] %s\n", resposta.mensagem);

    // --- CRIAÇÃO DO PIPE DE MONITORIZAÇÃO ---
    // Pipe apenas para o filho saber se o pai morreu.
    int pipe_monitor[2];
    if (pipe(pipe_monitor) == -1) {
        perror("[ERRO] Pipe monitor");
        return 1;
    }

    if (fork() == 0) {
        // --- PROCESSO FILHO ---
        close(pipe_monitor[1]); // Fecha a escrita (o filho só lê/observa)
        
        // Reset sinais para o default (morre silenciosamente)
        signal(SIGINT, SIG_DFL);
        signal(SIGTERM, SIG_DFL);
        
        // Passamos o lado de leitura para a função
        receberMensagens(pipe_monitor[0]); 
        exit(0);
    }

    // --- PROCESSO PAI ---
    close(pipe_monitor[0]); // Fecha a leitura (o pai só segura a escrita)
    
    // O pai fica aqui no menu.
    // Enquanto o pai estiver vivo, pipe_monitor[1] está aberto.
    // Se o pai morrer (kill, crash, exit), o SO fecha pipe_monitor[1].
    // Isso envia End of File para pipe_monitor[0] no filho, desbloqueando o select.
    enviarComandos(argv[1]);
    
    return 0;
}