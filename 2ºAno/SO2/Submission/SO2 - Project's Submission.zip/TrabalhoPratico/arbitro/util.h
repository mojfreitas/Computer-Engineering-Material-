#ifndef UTIL_H
#define UTIL_H

#include <windows.h>
#include <tchar.h>
#include <io.h>
#include <stdio.h>
#include <fcntl.h>
#include <math.h> 
#include <string.h>


#define PIPE_NAME _T("\\\\.\\pipe\\teste")
#define MAX_JOGADORES 20
#define MAX_TAMANHO_PALAVRA 20
#define TEMPO_ESPERA_CONEXAO 5000
#define MAX_USERNAME 20
#define MAX_PALAVRA 100
#define BUFFER_SIZE 256
#define MAXLETRAS_LIMITE 12
#define TAM_BUFFER 256

#define SHM_NAME _T("SharedMemTrabSO2")
#define MUTEX_LETRAS _T("MutexLetrasTrabSO2")
#define EVENTO_LETRAS _T("EventoLetrasTrabSO2")




typedef struct {
    TCHAR letras[MAXLETRAS_LIMITE];
    DWORD tempo[MAXLETRAS_LIMITE];
    DWORD maxLetras;
    DWORD ritmo;
} SDATA;

// Estrutura para comunica��o via pipe
typedef struct {
    TCHAR username[TAM_BUFFER];
    TCHAR comando[TAM_BUFFER];
    TCHAR msg[TAM_BUFFER];
} DADOS;

// Estrutura para thread de letras
typedef struct {
    HANDLE hMutex;
    HANDLE hEvento;
    SDATA* pShm;
    BOOL continua;
} dThreadEletras;

// Estrutura para thread de leitura de letras
typedef struct {
    HANDLE hMutex;
    HANDLE hEvento;
    SDATA* pShm;
    BOOL continua;
} dThreadLeletras;


#endif // UTIL_H



