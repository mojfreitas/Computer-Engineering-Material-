#include "..\arbitro\util.h"

/*// Interface gr�fica
void criarJanelaPrincipal();
void atualizarInterface(MemPartilhada* mem, const Jogador* jogadores, int num_jogadores);

// Atualiza��o de dados
void lerDadosJogo(MemPartilhada* mem, EstadoJogo* estado);
void ordenarJogadoresPorPontuacao(Jogador* jogadores, int num_jogadores);*/