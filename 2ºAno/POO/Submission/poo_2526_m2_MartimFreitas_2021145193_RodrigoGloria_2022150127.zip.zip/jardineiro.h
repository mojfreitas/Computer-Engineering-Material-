//
// Created by Rodrigo on 17/11/2025.
//

#ifndef TRABALHOPRATICO_JARDINEIRO_H
#define TRABALHOPRATICO_JARDINEIRO_H

#include "Ferramentas/ferramentas.h"
#include "Settings.h"
#include <algorithm>
#include <vector>
#include <iostream>


class Ferramentas;

class Jardineiro {
private:
    bool dentroDoJardim;
    int linha;
    int coluna;
    Ferramentas* ferramentaNaMao;
    int movimentosFeitos;
    int plantasPlantadas;
    int plantasColhidas;
    std::vector <Ferramentas*> mochila;
    int saude;
    char orientacao;


public:
    Jardineiro();
    ~Jardineiro();
    Jardineiro(const Jardineiro& copia);
    //estado jardineiro
    bool estaNoJardim() const {return dentroDoJardim;}
    void entrar(int l, int c);
    void sair();
    void setPosicao(int l, int c);
    int getLinha() const {return linha;}
    int getColuna() const {return coluna;}
    static const int saude_max = 60;

    //Gestao ferramentas
    void apanharFerramenta(Ferramentas* f);
    bool equiparFerramenta(int id);
    void largarFerramenta();
    Ferramentas* getFerramentaNaMao() const {return ferramentaNaMao;}

    const std::vector<Ferramentas*>& getMochila () const {return mochila;}


    void resetarAcoes();
    bool podeMover() const;
    void registarMovimento();
    void registarPlantacao();
    void verificarFerramentaNaMao();
    bool podeColher() const;
    bool podePlantar() const;
    void registarColheita();

    void receberDano(int dano);
    bool estaVivo() const {return saude > 0;}

    void setOrientacao(char o) { orientacao = o; }
    char getOrientacao() const { return orientacao; }

};


#endif //TRABALHOPRATICO_JARDINEIRO_H
