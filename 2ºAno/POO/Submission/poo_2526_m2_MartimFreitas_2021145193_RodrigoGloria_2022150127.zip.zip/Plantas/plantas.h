//
// Created by Rodrigo on 29/10/2025.
//

#ifndef TRABALHOPRATICO_PLANTAS_H
#define TRABALHOPRATICO_PLANTAS_H
#include "../Jardim/jardim.h"
class Solo;
class Plantas {
protected:
    int agua;
    int nutrientes;
    int idade;
    int beleza;
public:
    virtual ~Plantas() {}
    virtual void simular(Jardim& jardim, int l, int c) = 0;
    virtual char getTipo() const = 0;
    //virtual int getBeleza() const = 0;
    virtual Plantas* clone() const = 0;

    void setAgua(int a) { agua = a; }
    void setNutrientes(int n) { nutrientes = n; }

    int getAgua() const { return agua; }
    int getNutrientes() const { return nutrientes; }

};


#endif //TRABALHOPRATICO_PLANTAS_H
