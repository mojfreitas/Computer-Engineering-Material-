//
// Created by Rodrigo on 05/12/2025.
//

#ifndef TRABALHOPRATICO_LIRIO_H
#define TRABALHOPRATICO_LIRIO_H
#include "plantas.h"
#include "../Jardim/jardim.h"
#include "../Solo.h"

class Lirio : public Plantas{
public:
    // Constante de Dano definida aqui
    static const int dano_causado = 20;
    Lirio();
    Lirio* clone() const override {return new Lirio(*this);}
    char getTipo() const override { return 'x'; }

    // Podes implementar o simular normal (crescer/morrer) se quiseres
    void simular(Jardim& jardim, int l, int c) override;
};


#endif //TRABALHOPRATICO_LIRIO_H
