//
// Created by Rodrigo on 29/10/2025.
//

#ifndef TRABALHOPRATICO_ERVA_H
#define TRABALHOPRATICO_ERVA_H
#include "plantas.h"
#include "../Jardim/jardim.h"
#include "../Solo.h"
#include "../Settings.h"
#include "../Jardim/posicao.h"
#include <iostream>
#include <vector>
#include <cstdlib>

class Erva : public Plantas {
    int idade;
    int contadorReproducao;
public:
    Erva();
    Erva* clone() const override { return new Erva(*this); }
    void simular(Jardim& jardim, int l, int c) override;
    char getTipo() const override { return 'e'; }
};


#endif //TRABALHOPRATICO_ERVA_H
