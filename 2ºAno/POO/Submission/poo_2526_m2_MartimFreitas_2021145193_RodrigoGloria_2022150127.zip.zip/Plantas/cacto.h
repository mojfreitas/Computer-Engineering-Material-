//
// Created by Rodrigo on 29/10/2025.
//

#ifndef TRABALHOPRATICO_CACTO_H
#define TRABALHOPRATICO_CACTO_H
#include "plantas.h"
#include "../Jardim/jardim.h"
#include "../Solo.h"
#include "../Settings.h"
#include "../Jardim/posicao.h"
#include <iostream>
#include <vector>
#include <cstdlib>
#include <algorithm>

class Cacto : public Plantas {
private:
    int diasComAguaAMais;
    int diasSemNutrientes;
public:
    Cacto();
    Cacto* clone() const override {return new Cacto(*this);}
    void simular(Jardim& jardim, int l, int c) override;
    char getTipo() const override { return 'c'; }
    //int getBeleza() const override { return 1;}

};


#endif //TRABALHOPRATICO_CACTO_H
