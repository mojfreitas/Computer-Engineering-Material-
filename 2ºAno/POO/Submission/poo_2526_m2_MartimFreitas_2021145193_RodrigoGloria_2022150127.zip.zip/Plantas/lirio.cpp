//
// Created by Rodrigo on 05/12/2025.
//

#include "lirio.h"

using namespace std;

Lirio::Lirio() {
    this->agua = 10;
    this->nutrientes = 20;
    this->idade = 0;
    this->beleza =2;
}

void Lirio::simular(Jardim &jardim, int l, int c) {
    Solo *solo = jardim.getSolo(l,c);

    solo->retirarAgua(1);
    this->agua += 1;
    solo->retirarNutrientes(1);
    this->nutrientes += 1;

    if (this->agua <= 0 || this->nutrientes <= 0) {
        cout << "Lirio murchou em " << (char)('a'+l) << (char)('a'+c) << endl;
        solo->setPlanta(nullptr); // Morre
    }
}