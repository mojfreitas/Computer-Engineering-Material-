//
// Created by Rodrigo on 29/10/2025.
//

#ifndef TRABALHOPRATICO_ROSEIRA_H
#define TRABALHOPRATICO_ROSEIRA_H
#include "plantas.h"
#include "../Jardim/jardim.h"
#include "../Solo.h"
#include "../Settings.h"
#include "../Jardim/posicao.h"
#include <vector>
#include <cstdlib>
#include <algorithm> // Para usar std::min
#include <iostream>

class Roseira : public Plantas {
public:
    Roseira();
    Roseira* clone() const override { return new Roseira(*this); }
    void simular(Jardim& jardim, int l, int c) override;
    char getTipo() const override { return 'r'; }
    //int getBeleza() const override { return 3;}


};


#endif //TRABALHOPRATICO_ROSEIRA_H
