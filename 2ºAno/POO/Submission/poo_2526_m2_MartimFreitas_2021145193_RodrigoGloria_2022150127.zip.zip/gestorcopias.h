//
// Created by Rodrigo on 27/12/2025.
//

#ifndef TRABALHOPRATICO_GESTORCOPIAS_H
#define TRABALHOPRATICO_GESTORCOPIAS_H
#include <map>
#include <string>
#include "Jardim/jardim.h"

class GestorCopias {
    static std::map<std::string, Jardim*> copiasExistentes;
public:
    static void gravarCopia(const std::string& nome, Jardim* jardim) {
        if(copiasExistentes.find(nome) != copiasExistentes.end()) {
            delete copiasExistentes[nome];
        }
        copiasExistentes[nome] = new Jardim(*jardim);
    }
    static Jardim* recuperarCopia(const std::string& nome) {
        if(copiasExistentes.find(nome) != copiasExistentes.end()) {
            Jardim* copia = copiasExistentes[nome];
            copiasExistentes.erase(nome);
            return copia;
        }
        return nullptr;
    }

    static bool apagarCopia(const std::string& nome) {
        auto it = copiasExistentes.find(nome);
        if(it != copiasExistentes.end()) {
            delete it->second;
            copiasExistentes.erase(it);
            return true;
        }
        return false;
    }
};


#endif //TRABALHOPRATICO_GESTORCOPIAS_H
