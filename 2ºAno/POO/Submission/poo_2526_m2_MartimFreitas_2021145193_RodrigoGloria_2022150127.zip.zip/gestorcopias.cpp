//
// Created by Rodrigo on 27/12/2025.
//

#include "gestorcopias.h"
#include <map>
#include <string>

std::map<std::string, Jardim*> GestorCopias::copiasExistentes;
