//
// Created by Rodrigo on 29/10/2025.
//

#include "comandoplantas.h"
#include <string>
#include <sstream>
#include <iostream>
#include <cctype>


using namespace std;

bool ComandoPlanta::executar(Jardim*& jardim, std::stringstream& parametros)  {
    // esperar: "<linha> <coluna> <tipoChar>"
    //cout << "DEBUG: Executando comando '" << nomeComando << "'" << endl;
    if(nomeComando == "planta") {
        std::string posStr;
        char tipoChar;

        if (!(parametros >> posStr >> tipoChar)) {
            cout << "Parametros invalidos. Uso: planta <linha><coluna> <tipo>\n";
            return false;
        }

        // 1. Obter o Jardineiro e verificar Limites
        Jardineiro* j = jardim->getJardineiro();

        // Se já plantou 2 vezes neste turno, impede a ação
        if (!j->podePlantar()) {
            cout << "O jardineiro esta cansado! Limite de plantacoes por turno atingido." << endl;
            cout << "Use 'avanca' para descansar." << endl;
            return false;
        }

        try {
            Posicao p = Posicao::deString(posStr);

            // Validar se está dentro do jardim
            if (!p.ehValida(jardim->getLinhas(), jardim->getColunas())) {
                cout << "Posicao fora do jardim." << endl;
                return false;
            }

            Solo *solo = jardim->getSolo(p.getLinha(), p.getColuna());

            // 2. Verificar se JÁ TEM PLANTA (Ferramentas não impedem plantar)
            if (solo->getPlanta() != nullptr) {
                cout << "Ja existe uma planta nessa posicao." << endl;
                return false;
            }

            Plantas *novaPlanta = nullptr;
            string nome;

            tipoChar = static_cast<char>(tolower(static_cast<unsigned char>(tipoChar)));

            switch (tipoChar) {
                case 'c':
                    novaPlanta = new Cacto();
                    nome = "cacto";
                    break;
                case 'r':
                    novaPlanta = new Roseira();
                    nome = "roseira";
                    break;
                case 'e':
                    novaPlanta = new Erva();
                    nome = "erva daninha";
                    break;
                case 'x':
                    novaPlanta = new Lirio();
                    nome = "lirio";
                    break;
                default:
                    cout << "Tipo de planta invalido (use c, r, e, x)." << endl;
                    return false;
            }

            if (novaPlanta != nullptr) {
                char tipo = novaPlanta->getTipo();
                solo->setPlanta(novaPlanta);

                // 3. REGISTAR A AÇÃO NO JARDINEIRO
                j->registarPlantacao();

                cout << "Plantou " << nome << " (" << tipo << ") na posicao " << posStr << endl;
                return true;
            }

        } catch (...) {
            cout << "Posicao invalida (ex: use 'aa', 'ab')." << endl;
            return false;
        }
    }
    else if(nomeComando == "lplantas") {
        cout << "=== Plantas no Jardim ===" << endl;
        bool encontrouPlantas = false;

        for (int l = 0; l < jardim->getLinhas(); l++) {
            for(int c = 0; c < jardim->getColunas(); c++) {
                Solo* solo = jardim->getSolo(l,c);

                // 4. Só listamos se houver PLANTA (ignora se houver só ferramenta)
                if(solo && solo->getPlanta() != nullptr) {
                    encontrouPlantas = true;
                    Plantas* planta = solo->getPlanta();
                    string nomePlanta;

                    switch(planta->getTipo()) {
                        case 'c': nomePlanta = "Cacto"; break;
                        case 'r': nomePlanta = "Roseira"; break;
                        case 'e': nomePlanta = "Erva Daninha"; break;
                        case 'x': nomePlanta = "Lirio"; break; // Corrigido de "Lírico"
                        default: nomePlanta = "Desconhecida"; break;
                    }

                    char lChar = (char)('a' + l);
                    char cChar = (char)('a' + c);

                    cout << "[" << lChar << cChar << "] " << nomePlanta
                         << " (Agua: " << planta->getAgua()
                         << ", Nut: " << planta->getNutrientes() << ")" << endl;
                }
            }
        }
        if(!encontrouPlantas) {
            cout << "Nenhuma planta no jardim." << endl;
        }
        return true;
    }
    else if (nomeComando == "lplanta") {
        string posStr;
        // 1. Tentar ler a posição (ex: lplanta aa)
        if (parametros >> posStr) {
            try {
                Posicao p = Posicao::deString(posStr);

                // 2. Validar se está dentro do jardim
                if (!p.ehValida(jardim->getLinhas(), jardim->getColunas())) {
                    cout << "Posicao fora do jardim." << endl;
                    return false;
                }

                Solo* solo = jardim->getSolo(p.getLinha(), p.getColuna());
                Plantas* planta = solo->getPlanta();

                // 3. Verificar se existe planta
                if (planta != nullptr) {
                    string nomePlanta;
                    switch(planta->getTipo()) {
                        case 'r': nomePlanta = "Roseira"; break;
                        case 'c': nomePlanta = "Cacto"; break;
                        case 'e': nomePlanta = "Erva Daninha"; break;
                        case 'x': nomePlanta = "Lirio"; break;
                        default: nomePlanta = "Desconhecida"; break;
                    }

                    cout << "--- Informacao da Planta em " << posStr << " ---" << endl;
                    cout << "Especie: " << nomePlanta << " (" << planta->getTipo() << ")" << endl;
                    cout << "Estado Interno:" << endl;
                    cout << "  -> Agua Acumulada: " << planta->getAgua() << endl;
                    cout << "  -> Nutrientes Acumulados: " << planta->getNutrientes() << endl;



                } else {
                    cout << "Nao existe nenhuma planta na posicao " << posStr << "." << endl;
                }
                return true;

            } catch (...) {
                cout << "Posicao invalida (use formato 'aa', 'ab')." << endl;
                return false;
            }
        } else {
            cout << "Sintaxe incorreta. Use: lplanta <linha><coluna>" << endl;
            return false;
        }
    }
    return false;
}