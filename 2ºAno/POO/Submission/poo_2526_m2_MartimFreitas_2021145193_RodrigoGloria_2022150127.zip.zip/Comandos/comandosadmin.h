//
// Created by Rodrigo on 27/12/2025.
//

#ifndef TRABALHOPRATICO_COMANDOSADMIN_H
#define TRABALHOPRATICO_COMANDOSADMIN_H
#include "comando.h"
#include <string>



class Comandosadmin : public Comando {
private:
    std::string nomeComando;
public:
    Comandosadmin(std::string nome) : nomeComando(nome) {};
    std::string getNome() const override { return nomeComando; }
    bool executar(Jardim*& jardim, std::stringstream& parametros) override;

};


#endif //TRABALHOPRATICO_COMANDOSADMIN_H
