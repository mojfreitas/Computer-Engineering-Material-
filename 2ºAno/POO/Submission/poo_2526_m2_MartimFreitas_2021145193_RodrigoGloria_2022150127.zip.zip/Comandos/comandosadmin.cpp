//
// Created by Rodrigo on 27/12/2025.
//

#include "comandosadmin.h"
#include "../gestorcopias.h"
#include "../interpretador.h"
#include <iostream>
#include <fstream>
#include <cstdlib>

using namespace std;

bool Comandosadmin::executar(Jardim*& jardim, std::stringstream& parametros) {

    // --- COMANDO: GRAVA ---
    if (nomeComando == "grava") {
        string nome;
        if (parametros >> nome) {
            if (jardim == nullptr) {
                cout << "Erro: Nao ha jardim para gravar." << endl;
                return false;
            }
            // Chama o gestor que faz a Deep Copy (clone)
            GestorCopias::gravarCopia(nome, jardim);
            cout << "Jardim gravado com o nome '" << nome << "'." << endl;
            return true;
        }
    }

        // --- COMANDO: RECUPERA ---
    else if (nomeComando == "recupera") {
        string nome;
        if (parametros >> nome) {
            // O Gestor devolve uma cópia ou o ponteiro guardado
            Jardim* recuperado = GestorCopias::recuperarCopia(nome);

            if (recuperado != nullptr) {
                delete jardim;       // Apaga o jardim atual (Liberta memória!)
                jardim = recuperado; // Aponta para o novo
                cout << "Jardim '" << nome << "' recuperado." << endl;
                return true;
            } else {
                cout << "Erro: Save nao encontrado." << endl;
                return false;
            }
        }
    }

        // --- COMANDO: APAGA ---
    else if (nomeComando == "apaga") {
        string nome;
        if (parametros >> nome) {
            if (GestorCopias::apagarCopia(nome)) {
                cout << "Save '" << nome << "' apagado." << endl;
                return true;
            } else {
                cout << "Erro: Save nao encontrado." << endl;
                return false;
            }
        }
    }

        // --- COMANDO: EXECUTA (Ficheiros de texto) ---
    else if (nomeComando == "executa") {
        string ficheiroNome;
        if (parametros >> ficheiroNome) {
            ifstream ficheiro(ficheiroNome);
            if (!ficheiro.is_open()) {
                cout << "Erro ao abrir ficheiro: " << ficheiroNome << endl;
                return false;
            }

            cout << "--- A executar comandos de " << ficheiroNome << " ---" << endl;

            // Cria um interpretador temporário para ler o ficheiro
            Interpretador interpretadorAux;
            string linha;
            while (getline(ficheiro, linha)) {
                // Ignora linhas vazias
                if(linha.empty()) continue;

                if (linha == "fim") {
                    cout << "Comando 'fim' encontrado. A terminar execucao do script." << endl;
                    if (jardim != nullptr) {
                        cout << "\n=== ESTADO FINAL DO JARDIM ===\n";
                        jardim->desenhar();
                    }
                    delete jardim;
                    jardim = nullptr;
                    exit(0);
                }

                cout << ">> " << linha << endl;
                interpretadorAux.processarComando(linha, jardim);
            }
            ficheiro.close();
            cout << "--- Fim da execucao ---" << endl;
            return true;
        }
    }

    return false;
}