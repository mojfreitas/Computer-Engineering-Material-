//
// Created by Rodrigo on 05/12/2025.
//

#ifndef TRABALHOPRATICO_COMANDOSOLO_H
#define TRABALHOPRATICO_COMANDOSOLO_H

#include "comando.h"
#include "../Jardim/posicao.h"
#include "../Solo.h"
#include <iostream>

class ComandoSolo : public Comando {
    std::string nomeComando;
public:
    ComandoSolo(const std::string& nome) : nomeComando(nome) {}
    std::string getNome() const override { return nomeComando; } // ou 'lsolo' conforme enunciado
    bool executar(Jardim*& jardim, std::stringstream& parametros) override;
};


#endif //TRABALHOPRATICO_COMANDOSOLO_H
