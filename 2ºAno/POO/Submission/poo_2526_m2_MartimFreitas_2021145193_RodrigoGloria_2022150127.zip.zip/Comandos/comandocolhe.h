//
// Created by Rodrigo on 05/12/2025.
//

#ifndef TRABALHOPRATICO_COMANDOCOLHE_H
#define TRABALHOPRATICO_COMANDOCOLHE_H


#include "comando.h"
#include "../Jardim/posicao.h"
#include "../Solo.h"
#include "../Settings.h"
#include <iostream>

class ComandoColhe : public Comando {
public:
    std::string getNome() const override { return "colhe"; }
    bool executar(Jardim*& jardim, std::stringstream& parametros) override;
};

#endif //TRABALHOPRATICO_COMANDOCOLHE_H
