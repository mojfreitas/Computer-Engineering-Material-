#include <iostream>
#include "jardim.h"
#include "../Solo.h"       // Include necessário para .cpp
#include "../Plantas/plantas.h" // Include necessário para .cpp
#include "../Ferramentas/ferramentas.h" // Include necessário para .cpp
#include "../Ferramentas/regador.h"
#include "../Ferramentas/adubo.h"
#include "../Ferramentas/tesoura.h"
#include "../Ferramentas/gadanha.h"


using namespace std;

Jardim::Jardim(int l, int c) : linhas(l), colunas(c){
    jardineiro = new Jardineiro();

    area = new Solo*[linhas];
    for(int i = 0; i < linhas; i++) {
        area[i] = new Solo[colunas];
    }
    inicializarFerramentas();
}


Jardim::~Jardim() {
    for(int i = 0; i < linhas; i++) {
        delete[] area[i];
    }
    delete[] area;
    delete jardineiro;
}

void Jardim::desenhar() const {

    // 1. RÉGUA SUPERIOR (imprime tudo numa linha, acaba com endl)
    cout << "   ";
    for(int c = 0; c < colunas; c++) {
        cout << " " << static_cast<char>('A' + c);
    }
    cout << endl; // <-- SÓ 1 endl no fim

    // 2. LINHA SEPARADORA SUPERIOR
    cout << "  +";
    for(int c = 0; c < colunas; c++) {
        cout << "--";
    }
    cout << "-+" << endl; // <-- SÓ 1 endl no fim

    // 3. CONTEÚDO DO JARDIM (O loop principal)
    for(int l = 0; l < linhas; l++) {

        // Imprime a régua da linha (ex: "A |")
        cout << static_cast<char>('A' + l) << " |";

        // Loop das colunas: imprime TODOS os solos dessa linha
        for(int c = 0; c < colunas; c++) {

            Solo* solo =  &area[l][c];

            if (jardineiro->estaNoJardim() &&
                jardineiro->getLinha() == l &&
                jardineiro->getColuna() == c) {
                cout << " *";
            } else if(solo->getPlanta() != nullptr) {
                cout << " " << solo->getPlanta()->getTipo();  // 2. Planta
            } else if (solo->getFerramenta() != nullptr) {
                cout << " " << solo->getFerramenta()->getTipo(); // 3. Ferramenta
            } else {
                cout << "  ";  // 4. Vazio
            }
            // NENHUM endl aqui dentro
        }

        // Imprime a borda direita e SÓ AGORA salta a linha
        cout << " |" << endl;
    }

    // 4. LINHA SEPARADORA INFERIOR
    cout << "  +";
    for(int c = 0; c < colunas; c++) {
        cout << "--";
    }
    cout << "-+" << endl; // <-- SÓ 1 endl no fim
}

void Jardim::reporFerramenta() {
    int l, c;
    Solo* soloAlvo;
    // Antes: while (!soloAlvo->estaVazio() || ...) -> Bloqueava se houvesse plantas
    // Agora: while (soloAlvo->getFerramenta() != nullptr) -> Só bloqueia se já houver ferramenta
    int tentativas = 0;
    do {
        l = rand() % linhas;
        c = rand() % colunas;
        soloAlvo = getSolo(l, c);
        tentativas++;
        // Proteção extra: se tentar 1000 vezes e não conseguir (jardim cheio de ferramentas), desiste
        if (tentativas > 1000) return;

    } while (soloAlvo->getFerramenta() != nullptr);

    int tipo = rand() % 4;
    Ferramentas *novaFerramenta = nullptr;

    switch (tipo) {
        case 0: novaFerramenta = new Regador(); break;
        case 1: novaFerramenta = new Adubo(); break;
        case 2: novaFerramenta = new Tesoura(); break;
        case 3: novaFerramenta = new Gadanha(); break;
    }

    if (novaFerramenta != nullptr) {
        soloAlvo->setFerramenta(novaFerramenta);
    }
}

void Jardim::inicializarFerramentas() {
    int tipoFerramentas = 4;
    // Vamos por 3 ferramentas no mapa
    for (int i = 0; i < 3; i++) {
        int c, l;
        Solo* soloAlvo;
        do {
            l = rand() % linhas;
            c = rand() % colunas;
            soloAlvo = getSolo(l,c);
        } while (!soloAlvo->estaVazio() || soloAlvo->getFerramenta() != nullptr);

        int tipo = rand() % tipoFerramentas;
        Ferramentas *novaFerramenta = nullptr;
        switch (tipo) {
            case 0: novaFerramenta = new Regador(); break;
            case 1: novaFerramenta = new Adubo(); break;
            case 2: novaFerramenta = new Tesoura(); break;
            case 3: novaFerramenta = new Gadanha(); break;
        }
        if(novaFerramenta != nullptr) {
            soloAlvo->setFerramenta(novaFerramenta);
        }
    }
}

void Jardim::verificarRecolhaFerramenta() {
    // 1. Verificar se o jardineiro está no jardim
    if (!jardineiro->estaNoJardim()) return;

    int l = jardineiro->getLinha();
    int c = jardineiro->getColuna();
    Solo* soloAtual = getSolo(l, c);

    // 2. Verificar se há ferramenta no chão
    if (soloAtual != nullptr && soloAtual->getFerramenta() != nullptr) {
        //guarda ponteiro antigo
        Ferramentas* ferrAntiga = soloAtual->getFerramenta();

        // 3. O jardineiro guarda na mochila
        jardineiro->apanharFerramenta(ferrAntiga);

        cout << "--> Apanhou automaticamente: " << ferrAntiga->getTipo()
             << " (ID: " << ferrAntiga->getID() << ")" << endl;

        //limpamos o solo
        soloAtual->setFerramenta(nullptr);

        // 5. REGRA DA MAGIA: Criar uma nova noutro local aleatório
        reporFerramenta();
        cout << "--> Uma nova ferramenta apareceu magicamente no jardim!" << endl;
    }
}

void Jardim::simularInstante() {
    for (int l = 0; l < linhas; l++) {
        for (int c = 0; c < colunas; c++) {
            Solo* solo = getSolo(l, c);

            // 1. Plantas agem
            if (solo->getPlanta() != nullptr) {
                solo->getPlanta()->simular(*this, l, c);
            }

            // 2. Ferramentas agem (se o jardineiro estiver lá)
            if (jardineiro->estaNoJardim() &&
                jardineiro->getLinha() == l &&
                jardineiro->getColuna() == c) {

                Ferramentas* fer = jardineiro->getFerramentaNaMao();
                if (fer != nullptr) {
                    fer->simular(*this, l, c);
                }

            }
        }
    }

    // Verificar fim de vida da ferramenta
    if (jardineiro->estaNoJardim()) {
        jardineiro->verificarFerramentaNaMao();
    }
}

Solo* Jardim::getSolo(int linha, int coluna) {
    if(linha >= 0 && linha < linhas && coluna >= 0 && coluna < colunas)
        return &area[linha][coluna];
    return nullptr;
}

Jardim::Jardim(const Jardim& outro) {
    this->linhas = outro.linhas;
    this->colunas = outro.colunas;

    // 1. Clonar o Jardineiro (Usa o construtor do passo anterior)
    this->jardineiro = new Jardineiro(*outro.jardineiro);

    // 2. Alocar nova memória para a matriz (Deep Copy da estrutura)
    this->area = new Solo*[linhas];
    for(int i = 0; i < linhas; i++) {
        area[i] = new Solo[colunas];
    }

    // 3. Copiar o conteúdo célula a célula
    for(int l = 0; l < linhas; l++) {
        for(int c = 0; c < colunas; c++) {
            // Nota: Como 'area' é Solo**, acedemos ao endereço original e destino
            Solo* original = &outro.area[l][c];
            Solo* copia = &this->area[l][c];

            // Copiar valores simples
            copia->setAgua(original->getAgua());
            copia->setNutrientes(original->getNutrientes());

            // Clonar Planta (se existir)
            if (original->getPlanta() != nullptr) {
                copia->setPlanta(original->getPlanta()->clone());
            }

            // Clonar Ferramenta (se existir)
            if (original->getFerramenta() != nullptr) {
                copia->setFerramenta(original->getFerramenta()->clone());
            }
        }
    }
}



