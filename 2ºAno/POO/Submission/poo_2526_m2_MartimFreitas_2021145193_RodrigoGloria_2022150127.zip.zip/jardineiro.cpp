//
// Created by Rodrigo on 17/11/2025.
//
#include "jardineiro.h"

using namespace std;

Jardineiro::Jardineiro()
        : dentroDoJardim(false), linha(0), coluna(0),
          ferramentaNaMao(nullptr), movimentosFeitos(0), plantasPlantadas(0), orientacao('b')  {
    this->saude = saude_max;
}

Jardineiro::~Jardineiro() {
    delete ferramentaNaMao;
    for (Ferramentas* f : mochila) {
        delete f;
    }
    mochila.clear();
}

void Jardineiro::entrar(int l, int c) {
    dentroDoJardim = true;
    linha = l;
    coluna = c;
}

void Jardineiro::sair() {
    dentroDoJardim = false;
}

void Jardineiro::setPosicao(int l, int c) {
    linha = l;
    coluna = c;
}

// --- Gestão de Ferramentas ---

void Jardineiro::apanharFerramenta(Ferramentas* f) {
    if (f != nullptr) {
        mochila.push_back(f);
    }
}

bool Jardineiro::equiparFerramenta(int id) {
    // Procura na mochila
    /*for (Ferramentas* f : mochila) {
        if (f->getID() == id) {
            ferramentaNaMao = f; // Coloca na mão
            return true;
        }
    }
    return false; // Não encontrou*/
    for (auto it = mochila.begin(); it != mochila.end(); ++it) {
        if ((*it)->getID() == id) {

            // Encontrou!
            Ferramentas* novaFerramenta = *it;

            // 2. Se já tiver algo na mão, devolve à mochila
            if (ferramentaNaMao != nullptr) {
                mochila.push_back(ferramentaNaMao);
                cout << "Guardou a ferramenta " << ferramentaNaMao->getTipo() << " na mochila." << endl;
            }

            // 3. Põe a nova na mão
            ferramentaNaMao = novaFerramenta;

            // 4. Remove a nova da mochila (agora só está na mão)
            mochila.erase(it);

            return true;
        }
    }
    return false;
}

void Jardineiro::largarFerramenta() {
    if (ferramentaNaMao != nullptr) {
        mochila.push_back(ferramentaNaMao);
        ferramentaNaMao = nullptr;
    }
}

void Jardineiro::verificarFerramentaNaMao() {
    // Como a ferramenta na mão JÁ NÃO ESTÁ na mochila, basta apagar a da mão.
    if (ferramentaNaMao != nullptr && ferramentaNaMao->gastou()) {
        cout << "A ferramenta " << ferramentaNaMao->getTipo()
             << " (ID: " << ferramentaNaMao->getID() << ") acabou e foi deitada fora!" << endl;

        delete ferramentaNaMao; // Apaga da memória
        ferramentaNaMao = nullptr; // Esvazia a mão
    }
}

// --- Gestão de Ações ---

void Jardineiro::resetarAcoes() {
    movimentosFeitos = 0;
    plantasPlantadas = 0;
    plantasColhidas = 0;
}

bool Jardineiro::podeMover() const {
    return movimentosFeitos < Settings::Jardineiro::max_movimentos;
}

bool Jardineiro::podeColher() const {
    return plantasColhidas < Settings::Jardineiro::max_colheitas;
}

bool Jardineiro::podePlantar() const {
    return plantasPlantadas < Settings::Jardineiro::max_plantacoes;
}

void Jardineiro::registarColheita() {
    plantasColhidas++;
}

void Jardineiro::registarMovimento() {
    movimentosFeitos++;
}

void Jardineiro::registarPlantacao() {
    plantasPlantadas++;
}

void Jardineiro::receberDano(int dano) {
    this->saude -= dano;
    if(this->saude< 0)
        this->saude = 0;
    cout << "Jardineiro sofreu " << dano << " de dano! Saude restante: " << this->saude << endl;
}

Jardineiro::Jardineiro(const Jardineiro& copia) {
    // 1. Cópia de tipos primitivos (int, bool, char)
    this->dentroDoJardim = copia.dentroDoJardim;
    this->linha = copia.linha;
    this->coluna = copia.coluna;
    this->saude = copia.saude;
    this->orientacao = copia.orientacao;
    this->movimentosFeitos = copia.movimentosFeitos;
    this->plantasPlantadas = copia.plantasPlantadas;
    this->plantasColhidas = copia.plantasColhidas;

    if (copia.ferramentaNaMao != nullptr) {
        this->ferramentaNaMao = copia.ferramentaNaMao->clone();
    } else {
        this->ferramentaNaMao = nullptr;
    }

    for (Ferramentas* f : copia.mochila) {
        this->mochila.push_back(f->clone());
    }
}