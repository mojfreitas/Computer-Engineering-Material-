//
// Created by Rodrigo on 16/11/2025.
//

#ifndef TRABALHOPRATICO_GADANHA_H
#define TRABALHOPRATICO_GADANHA_H
#include "ferramentas.h"
#include "../Jardim/jardim.h"
#include "../jardineiro.h" // Essencial para saber a orientação
#include "../Solo.h"
#include "../Plantas/plantas.h"   // Para ver o tipo da planta
#include <iostream>

class Gadanha : public Ferramentas{
public:
    Gadanha(){}
    Gadanha* clone() const override { return new Gadanha(*this); }
    char getTipo() const override { return 'z'; }
    void simular(Jardim& jardim, int l, int c) override;
};


#endif //TRABALHOPRATICO_GADANHA_H
