//
// Created by Rodrigo on 16/11/2025.
//

#include "regador.h"

using namespace std;

void Regador::simular(Jardim& jardim, int l, int c) {
    Solo *solo = jardim.getSolo(l, c);
    if (quantidade > 0) {

        solo->adicionarAgua(Settings::Regador::dose);
        quantidade -= Settings::Regador::dose;
    }
    cout << "Regador aplicado! Restam " << quantidade << " unidades de agua." << endl;
}
