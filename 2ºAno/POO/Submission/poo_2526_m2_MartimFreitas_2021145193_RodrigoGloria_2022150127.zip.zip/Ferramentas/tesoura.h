//
// Created by Rodrigo on 16/11/2025.
//

#ifndef TRABALHOPRATICO_TESOURA_H
#define TRABALHOPRATICO_TESOURA_H
#include "ferramentas.h"
#include "../Solo.h"
#include "../Plantas/plantas.h"
#include <iostream>
#include "../Plantas/lirio.h"

class Tesoura : public Ferramentas {
public:
    Tesoura(){}
    Tesoura* clone() const override { return new Tesoura(*this); }
    char getTipo() const override { return 't'; }
    //std::string getDetalhes() const override {return "Indestrutivel";}
    bool gastou() const override { return false; }
    void simular(Jardim& jardim, int l, int c) override;
};


#endif //TRABALHOPRATICO_TESOURA_H
