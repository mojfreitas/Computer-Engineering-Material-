//
// Created by Rodrigo on 16/11/2025.
//

#include "adubo.h"
#include "../Solo.h"
#include <iostream>

using namespace std;

void Adubo::simular(Jardim& jardim, int l, int c) {
    // Só atua se ainda tiver carga
    Solo* solo = jardim.getSolo(l, c);
    if (quantidade > 0) {
        solo->adicionarNutrientes(Settings::Adubo::dose); // Adiciona 10
        quantidade -= Settings::Adubo::dose; // Gasta 10

        cout << "Adubo aplicado! Restam " << quantidade << " doses." << endl;
    }
}