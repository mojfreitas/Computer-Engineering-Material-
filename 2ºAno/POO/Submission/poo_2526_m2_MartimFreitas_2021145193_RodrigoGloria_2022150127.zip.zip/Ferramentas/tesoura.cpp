//
// Created by Rodrigo on 16/11/2025.
//

#include "tesoura.h"
using namespace std;

void Tesoura::simular(Jardim& jardim, int l, int c) {
    Solo* solo = jardim.getSolo(l, c);

    if (solo->getPlanta() != nullptr) {
        char tipo = solo->getPlanta()->getTipo();

        // Se for o Lírio ('x'), aleija o jardineiro
        if (tipo == 'x') {
            cout << "CUIDADO! Tocaste no Lirio Venenoso!" << endl;
            Jardineiro* j = jardim.getJardineiro();

            j->receberDano(Lirio::dano_causado);

            if (!j->estaVivo()) {
                cout << "O JARDINEIRO MORREU!" << endl;
                j->sair(); // Game Over
            }
        } else if (tipo == 'e') {
            cout << "Cortaste uma erva daninha." << endl;
        }

        solo->setPlanta(nullptr); // Corta na mesma
    }
}