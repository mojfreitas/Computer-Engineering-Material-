//
// Created by Rodrigo on 16/11/2025.
//

#ifndef TRABALHOPRATICO_REGADOR_H
#define TRABALHOPRATICO_REGADOR_H
#include "ferramentas.h"
#include "../Solo.h"
#include "../Settings.h"
#include <iostream>

class Regador : public Ferramentas{
    int quantidade;
public:
    Regador() : quantidade(Settings::Regador::capacidade) {}
    Regador* clone() const override { return new Regador(*this); }
    char getTipo() const override { return 'g'; }
    /*std::string getDetalhes() const override {
        return "Agua: " + std::to_string(quantidade);
    }*/
    void simular(Jardim& jardim, int l, int c) override;
    bool gastou() const override { return quantidade <= 0; }
};


#endif //TRABALHOPRATICO_REGADOR_H
