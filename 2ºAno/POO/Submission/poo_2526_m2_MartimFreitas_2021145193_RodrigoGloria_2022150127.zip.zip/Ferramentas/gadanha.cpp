//
// Created by Rodrigo on 16/11/2025.
//

#include "gadanha.h"

void Gadanha::simular(Jardim& jardim, int l, int c) {
    Jardineiro* j = jardim.getJardineiro();
    char dir = j->getOrientacao(); // Pega a direção atual ('c', 'b', 'e', 'd')

    cout << "Gadanha ataca na direcao: " << dir << endl;

    // Define os 3 alvos relativos baseados na direção
    int offsets[3][2];

    if (dir == 'c') {      // Cima: Frente-Esq, Frente, Frente-Dir
        offsets[0][0] = -1; offsets[0][1] = -1;
        offsets[1][0] = -1; offsets[1][1] =  0;
        offsets[2][0] = -1; offsets[2][1] =  1;
    } else if (dir == 'b') { // Baixo
        offsets[0][0] =  1; offsets[0][1] = -1;
        offsets[1][0] =  1; offsets[1][1] =  0;
        offsets[2][0] =  1; offsets[2][1] =  1;
    } else if (dir == 'e') { // Esquerda
        offsets[0][0] = -1; offsets[0][1] = -1;
        offsets[1][0] =  0; offsets[1][1] = -1;
        offsets[2][0] =  1; offsets[2][1] = -1;
    } else if (dir == 'd') { // Direita
        offsets[0][0] = -1; offsets[0][1] =  1;
        offsets[1][0] =  0; offsets[1][1] =  1;
        offsets[2][0] =  1; offsets[2][1] =  1;
    }

    // Executa o corte
    for (int i = 0; i < 3; i++) {
        Solo* viz = jardim.getSolo(l + offsets[i][0], c + offsets[i][1]);

        if (viz != nullptr && viz->getPlanta() != nullptr) {
            char tipo = viz->getPlanta()->getTipo();
            cout << "Gadanha cortou " << tipo;
            if (tipo == 'x') cout << " (Sem dano!)";
            cout << endl;
            viz->setPlanta(nullptr);
        }
    }
}

