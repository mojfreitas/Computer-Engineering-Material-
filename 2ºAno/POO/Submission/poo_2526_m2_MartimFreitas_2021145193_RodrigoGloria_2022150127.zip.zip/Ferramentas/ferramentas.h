//
// Created by Rodrigo on 16/11/2025.
//

#ifndef TRABALHOPRATICO_FERRAMENTAS_H
#define TRABALHOPRATICO_FERRAMENTAS_H
#include <string>
//se há uma ferramenta na posiçao onde o jarneiro entra não apanha
//comando planta com duplicação de [debug]
//os comandos das ferramentas funcionam sem o jardineiro estar dentro do jardim


class Jardim;
class Solo;

class Ferramentas{
protected:
    int id;
    static int proximoID;
public:
    Ferramentas();
    virtual ~Ferramentas(){}
    virtual Ferramentas* clone() const = 0;

    virtual  char getTipo() const = 0;
    virtual void simular(Jardim& jardim, int l, int c) {}

    int getID () const {return id;}
    virtual bool gastou() const { return false; }
};


#endif //TRABALHOPRATICO_FERRAMENTAS_H
